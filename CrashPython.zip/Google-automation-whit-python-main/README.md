# Google-prefessional-automation-whit-python

Guia de habilidades trabajadas en este repositorio:
-Crash Course on Python
-Using Python to Interact with the Operating System
-Configuration Management and the Cloud
-Automating Real-World Tasks with Python
-Introduction to Git and GitHub
-Troubleshooting and Debugging Techniques
