for left in range(7):
    for rigth in range(left,7):
        print("["+ str(left) + "|" + str(rigth) +  "]", end =" ")
    print()    